package com.example.college_admission_reg_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class view_shortlist extends AppCompatActivity {
    ListView l1;
    SharedPreferences sh;
    String url;
    ArrayList<String> agency_arr, job_arr, jobdetails_arr, requirements_arr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_shortlist);
        l1 = findViewById(R.id.L6);
        sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        url = "http://" + sh.getString("ip", "") + ":5000/and_view_shortlist";
        RequestQueue queue = Volley.newRequestQueue(view_shortlist.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
//                Toast.makeText(send_complaint.this, "eeeerr" + response, Toast.LENGTH_SHORT).show();
                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {
                    JSONArray ar = new JSONArray(response);
                    if (ar.length() == 0){
                        Toast.makeText(view_shortlist.this, "not shortlisted" , Toast.LENGTH_SHORT).show();
                        Intent i1 = new Intent(getApplicationContext(), user_home.class);
                        startActivity(i1);
                    }
                    agency_arr = new ArrayList<>();
                    job_arr = new ArrayList<>();
                    requirements_arr = new ArrayList<>();
                    jobdetails_arr = new ArrayList<>();
                    for (int i=0; i<ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        agency_arr.add(jo.getString("agency"));
                        job_arr.add(jo.getString("job"));
                        requirements_arr.add(jo.getString("requirements"));
                        jobdetails_arr.add(jo.getString("jobdetails"));

                    }
//                    Toast.makeText(send_complaint.this, "err" + response, Toast.LENGTH_SHORT).show();


                    // ArrayAdapter<String> ad=new ArrayAdapter<>(Home.this,android.R.layout.simple_list_item_1,name);
                    //lv.setAdapter(ad);

                    l1.setAdapter(new custom_view_shortlist(view_shortlist.this,agency_arr, job_arr, jobdetails_arr, requirements_arr));
//                    l1.setOnItemClickListener(view_assigned_work_boy.this);

                }
                catch (Exception e) {
                    Toast.makeText(getApplicationContext(),"========="+e,Toast.LENGTH_LONG).show();
                    Log.d("=========", e.toString());
                }

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(view_shortlist.this, "err" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @NonNull
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("lid", sh.getString("lid", ""));
                return params;
            }
        };
        queue.add(stringRequest);



    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent ik = new Intent(getApplicationContext(), user_home.class);
        startActivity(ik);
    }

}