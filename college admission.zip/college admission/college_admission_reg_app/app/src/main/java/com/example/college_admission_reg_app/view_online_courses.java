package com.example.college_admission_reg_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class view_online_courses extends AppCompatActivity {
    SharedPreferences sh;
    ListView l1;
    String url;
    ArrayList<String> expert_arr, course_arr, details_arr, duration_arr, fee_arr, course_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_online_courses);
        l1 = findViewById(R.id.L4);
        sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        url = "http://" + sh.getString("ip", "") + ":5000/and_view_online_courses";
        RequestQueue queue = Volley.newRequestQueue(view_online_courses.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
//                Toast.makeText(send_complaint.this, "eeeerr" + response, Toast.LENGTH_SHORT).show();
                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {
//                    Toast.makeText(send_complaint.this, "" + response, Toast.LENGTH_SHORT).show();
                    JSONArray ar = new JSONArray(response);

                    expert_arr = new ArrayList<>();
                    course_arr = new ArrayList<>();
                    details_arr = new ArrayList<>();
                    duration_arr = new ArrayList<>();
                    fee_arr = new ArrayList<>();
                    course_id = new ArrayList<>();

                    for (int i=0; i<ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        expert_arr.add(jo.getString("expert"));
                        course_arr.add(jo.getString("course"));
                        details_arr.add(jo.getString("details"));
                        duration_arr.add(jo.getString("duration"));
                        fee_arr.add(jo.getString("fee"));
                        course_id.add(jo.getString("course_id"));

                    }
//                    Toast.makeText(send_complaint.this, "err" + response, Toast.LENGTH_SHORT).show();


                    // ArrayAdapter<String> ad=new ArrayAdapter<>(Home.this,android.R.layout.simple_list_item_1,name);
                    //lv.setAdapter(ad);

                    l1.setAdapter(new custom_view_online_courses(view_online_courses.this,expert_arr,
                            course_arr, details_arr, duration_arr, fee_arr, course_id));
//                    l1.setOnItemClickListener(view_assigned_work_boy.this);

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(),"========="+e,Toast.LENGTH_LONG).show();
                    Log.d("=========", e.toString());
                }

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(view_online_courses.this, "err" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @NonNull
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("lid", sh.getString("lid", ""));
                return params;
            }
        };
        queue.add(stringRequest);



    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent ik = new Intent(getApplicationContext(), user_home.class);
        startActivity(ik);
    }

}