package com.example.college_admission_reg_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class view_interview_info extends AppCompatActivity {
    ListView l1;
    SharedPreferences sh;
    String url;
    ArrayList<String> job, job_details, place, date, status, agency, requirements;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_interview_info);
        l1 = findViewById(R.id.L1);
        sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());


        url = "http://" + sh.getString("ip", "") + ":5000/and_view_interview_info";
        RequestQueue queue = Volley.newRequestQueue(view_interview_info.this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
//                Toast.makeText(send_complaint.this, "eeeerr" + response, Toast.LENGTH_SHORT).show();

                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {
//                    Toast.makeText(send_complaint.this, "" + response, Toast.LENGTH_SHORT).show();
                    JSONArray ar = new JSONArray(response);
                    if(ar.length() == 0){
//                        for (int i = 0; i < 60; i++) {
//                            for ( int j = 0; j < 10000; j++) {
//                            }
//                            }
                        Toast.makeText(view_interview_info.this, "Interview not scheduled", Toast.LENGTH_SHORT).show();
                        Intent i1 = new Intent(getApplicationContext(), user_home.class);
                        startActivity(i1);


                    }
                    agency = new ArrayList<>();
                    job = new ArrayList<>();
                    job_details = new ArrayList<>();
                    requirements = new ArrayList<>();
                    place = new ArrayList<>();
                    date = new ArrayList<>();
                    status = new ArrayList<>();

                    for (int i=0; i<ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        agency.add(jo.getString("agency"));
                        job.add(jo.getString("job"));
                        job_details.add(jo.getString("job_details"));
                        requirements.add(jo.getString("requirements"));
                        place.add(jo.getString("place"));
                        date.add(jo.getString("date"));
                        status.add(jo.getString("status"));

                    }
//                    Toast.makeText(send_complaint.this, "err" + response, Toast.LENGTH_SHORT).show();


                    // ArrayAdapter<String> ad=new ArrayAdapter<>(Home.this,android.R.layout.simple_list_item_1,name);
                    //lv.setAdapter(ad);

                    l1.setAdapter(new custom_view_interview_info(view_interview_info.this,agency, job, job_details, requirements, place, date, status));
//                    l1.setOnItemClickListener(view_assigned_work_boy.this);

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(),"========="+e,Toast.LENGTH_LONG).show();
                    Log.d("=========", e.toString());
                }

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(view_interview_info.this, "err" + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @NonNull
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("lid", sh.getString("lid", ""));
                return params;
            }
        };
        queue.add(stringRequest);



    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent ik = new Intent(getApplicationContext(), user_home.class);
        startActivity(ik);
    }

}