package com.example.college_admission_reg_app;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

class custom_job_request_status  extends BaseAdapter {
    private Context context;
    ArrayList<String> a, b, c, d, e, f, g;
    SharedPreferences sh;
    public custom_job_request_status(Context applicationContext, ArrayList<String> a, ArrayList<String> b,
                           ArrayList<String> c, ArrayList<String> d, ArrayList<String> e,
                           ArrayList<String> f, ArrayList<String> g ) {
        // TODO Auto-generated constructor stub
        this.context=applicationContext;
        this.a=a;
        this.b=b;
        this.c=c;
        this.d=d;
        this.e=e;
        this.f=f;
        this.g=g;
        sh=PreferenceManager.getDefaultSharedPreferences(applicationContext);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return a.size();
    }

    @Override
    public Object getItem(int arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getItemId(int arg0) {
        // TODO Auto-generated method stub
        return 0;
    }
    @Override
    public int getItemViewType(int arg0) {
        // TODO Auto-generated method stub
        return 0;
    }


    @Override
    public View getView(int position, View convertview, ViewGroup parent) {
        // TODO Auto-generated method stub
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(convertview==null)
        {
            gridView=new View(context);
            gridView=inflator.inflate(R.layout.activity_custom_job_request_status,null);

        }
        else
        {
            gridView=(View)convertview;

        }
        ///////////////////////
        if(android.os.Build.VERSION.SDK_INT>9)
        {
            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        /////////////////////////////////
//        ImageView i1=(ImageView) gridView.findViewById(R.id.imgaprtmnt);
        TextView tv1=(TextView)gridView.findViewById(R.id.TV1);
        TextView tv2=(TextView)gridView.findViewById(R.id.TV2);
        TextView tv3=(TextView)gridView.findViewById(R.id.TV3);
        TextView tv4=(TextView)gridView.findViewById(R.id.TV4);
        TextView tv5=(TextView)gridView.findViewById(R.id.TV5);
        TextView tv6=(TextView)gridView.findViewById(R.id.textView9);
        TextView tv7=(TextView)gridView.findViewById(R.id.textView10);
        Button b1=(Button) gridView.findViewById(R.id.button12);
//        Button b2=(Button) gridView.findViewById(R.id.button);

        if (g.get(position).equalsIgnoreCase("rejected")){
            b1.setVisibility(View.INVISIBLE);
            tv6.setVisibility(View.VISIBLE);
            tv7.setVisibility(View.INVISIBLE);
        }
        else if(g.get(position).equalsIgnoreCase("pending")){
            b1.setVisibility(View.INVISIBLE);
            tv6.setVisibility(View.INVISIBLE);
            tv7.setVisibility(View.VISIBLE);

        }
        else {
            tv6.setVisibility(View.INVISIBLE);
            tv7.setVisibility(View.INVISIBLE);
            b1.setVisibility(View.VISIBLE);
        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(context.getApplicationContext(), attend_test.class);
                i1.putExtra("j_id", f.get(position));
                context.startActivity(i1);

            }
        });

//        b2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Intent i1 = new Intent(context.getApplicationContext(), job_apply.class);
//                i1.putExtra("j_id", f.get(position));
//                context.startActivity(i1);
//
//            }
//        });
//        TextView tv5=(TextView)gridView.findViewById(R.id.tvnew);
//        java.net.URL thumb_u;
//        try {
//
//            //thumb_u = new java.net.URL("http://192.168.43.57:5000/static/photo/flyer.jpg");
//
//            thumb_u = new java.net.URL("http://"+sh.getString("ip","")+":5000/static/proof/"+b.get(position));
//            Drawable thumb_d = Drawable.createFromStream(thumb_u.openStream(), "src");
//            i1.setImageDrawable(thumb_d);
//        }
//        catch (Exception e)
//        {
//            Log.d("errsssssssssssss",""+e);
//        }

        tv1.setText(a.get(position));
        tv2.setText(b.get(position));
        tv3.setText(c.get(position));
        tv4.setText(d.get(position));
        tv5.setText(e.get(position));

        tv1.setTextColor(Color.BLACK);
        tv2.setTextColor(Color.BLACK);
        tv3.setTextColor(Color.BLACK);
        tv4.setTextColor(Color.BLACK);
        tv5.setTextColor(Color.BLACK);
        tv6.setTextColor(Color.RED);
        tv7.setTextColor(Color.BLUE);

        return gridView;

    }

}





