package com.example.college_admission_reg_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class user_home extends AppCompatActivity {

    //    Button b1, b5, b6, b7, b8, b9, b10;
    ImageView b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        b1 = findViewById(R.id.req_status);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button6);
        b6 = findViewById(R.id.button66);
//        b7 = findViewById(R.id.button666);
        b8 = findViewById(R.id.button6666);
        b9 = findViewById(R.id.button66666);
        b10 = findViewById(R.id.button7);
        b11 = findViewById(R.id.button8);
        b12 = findViewById(R.id.result);
        b13 = findViewById(R.id.I_clg);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), job_request_status.class);
                startActivity(i1);


            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), view_job.class);
                startActivity(i1);

            }
        });


        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), view_shortlist.class);
                startActivity(i1);

            }
        });


        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), view_interview_info.class);
                startActivity(i1);

            }
        });


        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), view_placement_details.class);
                startActivity(i1);

            }
        });


        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), view_online_courses.class);
                startActivity(i1);

            }
        });


//        b7.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Intent i1 = new Intent(getApplicationContext(), view_study_materials.class);
//                startActivity(i1);
//
//
//            }
//        });

        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), view_interview_videos.class);
                startActivity(i1);


            }
        });

        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), view_trends.class);
                startActivity(i1);


            }
        });

        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), send_complaint.class);
                startActivity(i1);

            }
        });

        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), login.class);
                startActivity(i1);

            }
        });
        b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), view_resultss.class);
                startActivity(i1);

            }
        });


        b13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i1 = new Intent(getApplicationContext(), view_colleges.class);
                startActivity(i1);

            }
        });


    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent ik = new Intent(getApplicationContext(), login.class);
        startActivity(ik);
    }

}