package com.example.college_admission_reg_app;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class job_apply extends AppCompatActivity {

    EditText e1;
    Button b1, b2;
    SharedPreferences sh;
    String file_str, url, title;
    String PathHolder = "";
    byte[] filedt = null;



    String fileName = "", path = "";
    private static final int FILE_SELECT_CODE = 0;
    String PathHolderr="";
    byte[] filedtt=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_apply);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        e1 = findViewById(R.id.editTextTextPersonName);
        b1 = findViewById(R.id.button10);
        b2 = findViewById(R.id.button11);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
//            intent.setType("application/pdf");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent, 7);


            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                file_str = e1.getText().toString();
                if (file_str.equalsIgnoreCase("")) {
                    e1.setError("choose your resume");
                }
                else {
                    uploadBitmap(title);
                }
            }
        });
    }





//    ProgressDialog pd;
//    private void uploadBitmap(final String title)
//    {
////        Toast.makeText(getApplicationContext(), "IIIIIIIIIIIIIIIIIIIII", Toast.LENGTH_LONG).show();
//        RequestQueue queue = Volley.newRequestQueue(job_apply.this);pd=new ProgressDialog(job_apply.this);
//        url = "http://" + sh.getString("ip","") + ":5000/job_request";
//        pd.setMessage("Uploading....");
//        pd.show();
//        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, url,
//                new Response.Listener<NetworkResponse>() {
//                    @Override
//                    public void onResponse(NetworkResponse response1) {
//                        pd.dismiss();
//                        String x=new String(response1.data);
//                        try {
//                            JSONObject obj = new JSONObject(new String(response1.data));
////                        Toast.makeText(Upload_agreement.this, "Report Sent Successfully", Toast.LENGTH_LONG).show();
//                            if (obj.getString("task").equalsIgnoreCase("success")) {
//                                Toast.makeText(job_apply.this, "Application sent Successfully", Toast.LENGTH_LONG).show();
//                                Intent i=new Intent(getApplicationContext(),view_job.class);
//                                startActivity(i);
//                            }
//                        } catch (Exception e) {
//                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
//                        }
//
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                }) {
//
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> params = new HashMap<>();
//
//                params.put("lid", sh.getString("lid", ""));
//                params.put("j_id", getIntent().getStringExtra("j_id"));
//
//
//                return params;
//            }
//
//            @Override
//            protected Map<String, DataPart> getByteData() {
//                Map<String, DataPart> params = new HashMap<>();
//                long imagename = System.currentTimeMillis();
//                params.put("file", new DataPart(PathHolder , filedt ));
//                return params;
//            }
//        };
//        Volley.newRequestQueue(job_apply.this).add(volleyMultipartRequest);
//    }
//    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
//    @Override
//    protected void onActivityResult(int requestCode,int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        switch (requestCode) {
//            case 7:
//                if (resultCode == RESULT_OK) {
//                    Uri uri = data.getData();
//                    Log.d("File Uri", "File Uri: " + uri.toString());
//                    // Get the path
//                    try {
//                        PathHolder = FileUtils.getPathFromURI(job_apply.this, uri);
////                        PathHolder = data.getData().getPath();
////                        Toast.makeText(this, PathHolder, Toast.LENGTH_SHORT).show();
//
//                        filedt = getbyteData(PathHolder);
//                        Log.d("filedataaa", filedt + "");
////                        Toast.makeText(this, filedt+"", Toast.LENGTH_SHORT).show();
//                        e1.setText(PathHolder);
//                    }
//                    catch (Exception e){
//                        Toast.makeText(job_apply.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                }
//                break;
//        }
//    }
//    private byte[] getbyteData(String pathHolder) {
//        Log.d("path", pathHolder);
//        File fil = new File(pathHolder);
//        int fln = (int) fil.length();
//        byte[] byteArray = null;
//        try {
//            InputStream inputStream = new FileInputStream(fil);
//            ByteArrayOutputStream bos = new ByteArrayOutputStream();
//            byte[] b = new byte[fln];
//            int bytesRead = 0;
//
//            while ((bytesRead = inputStream.read(b)) != -1) {
//                bos.write(b, 0, bytesRead);
//            }
//            byteArray = bos.toByteArray();
//            inputStream.close();
//        } catch (Exception e) {
//        }
//        return byteArray;
//    }



    ProgressDialog pd;
    private void uploadBitmap(final String title) {

        url = "http://" + sh.getString("ip","") + ":5000/job_request";
        pd=new ProgressDialog(job_apply.this);
        pd.setMessage("Uploading....");
        pd.show();
        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, url,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response1) {
                        pd.dismiss();
                        String x=new String(response1.data);
                        try {
                            JSONObject obj = new JSONObject(new String(response1.data));
//                        Toast.makeText(Upload_agreement.this, "Report Sent Successfully", Toast.LENGTH_LONG).show();
                            if (obj.getString("task").equalsIgnoreCase("success")) {

                                Toast.makeText(job_apply.this, "Application sent Successfully", Toast.LENGTH_LONG).show();
                                Intent i=new Intent(getApplicationContext(),view_job.class);
                                startActivity(i);
                            } else {
                                Toast.makeText(getApplicationContext(), "failed", Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();


                params.put("lid", sh.getString("lid", ""));
                params.put("j_id", getIntent().getStringExtra("j_id"));

                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put("file", new DataPart(PathHolder , filedt ));
//                params.put("f1", new DataPart(PathHolderr , filedtt ));

                return params;
            }
        };

        Volley.newRequestQueue(this).add(volleyMultipartRequest);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        Toast.makeText(getApplicationContext(),requestCode+"==>",Toast.LENGTH_LONG).show();
        switch (requestCode) {
            case 7:
                if (resultCode == RESULT_OK) {
                    Uri uri = data.getData();

                    Log.d("File Uri", "File Uri: " + uri.toString());
                    // Get the path
                    try {
                        PathHolder =FileUtils.getPathFromURI(this, uri);
//                        PathHolder = data.getData().getPath();
//                        Toast.makeText(this, PathHolder, Toast.LENGTH_SHORT).show();

                        filedt = getbyteData(PathHolder,uri);
                        Log.d("filedataaa", filedt + "");
                        Toast.makeText(this, filedt.length+"", Toast.LENGTH_SHORT).show();
                        e1.setText(PathHolder);
                    }
                    catch (Exception e){
//                        Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            case 6:
                if (resultCode == RESULT_OK) {
                    Uri uri = data.getData();
                    Log.d("File Urii", "File Urii: " + uri.toString());
                    // Get the path
                    try {
                        PathHolderr =FileUtils.getPathFromURI(this, uri);
//                        PathHolder = data.getData().getPath();
//                        Toast.makeText(this, PathHolder, Toast.LENGTH_SHORT).show();

                        filedtt = getbyteData(PathHolderr,uri);
                        Log.d("filedataaaa", filedtt + "");
                        Toast.makeText(this, filedtt.length+"", Toast.LENGTH_SHORT).show();
                        e1.setText(PathHolderr);
                    }
                    catch (Exception e){
                        Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                break;
        }
    }

    private byte[] getbyteData(String pathHolder,Uri suri) {
        Log.d("path", pathHolder);
        File fil = new File(pathHolder);
        int fln = (int) fil.length();
        byte[] byteArray = null;
        try {
            InputStream inputStream = new FileInputStream(fil);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[fln];
            int bytesRead = 0;

            while ((bytesRead = inputStream.read(b)) != -1) {
                bos.write(b, 0, bytesRead);
            }
            byteArray = bos.toByteArray();
            inputStream.close();
        } catch (Exception e) {
//            Toast.makeText(getApplicationContext(),"++"+e,Toast.LENGTH_LONG).show();
            File file = new File(pathHolder);
            if (file.exists()) {
                Toast.makeText(getApplicationContext(),"file exist",Toast.LENGTH_LONG).show();

            } else {

            }
            try {

                InputStream inputStream = getContentResolver().openInputStream(suri);

//                String ss="com."+pathHolder.split("com.")[1];
//                Uri fileUri = Uri.parse(ss);
//                InputStream inputStream = getContentResolver().openInputStream(fileUri);


                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int bytesRead;

                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    byteArrayOutputStream.write(buffer, 0, bytesRead);
                }

                return byteArrayOutputStream.toByteArray();
//                FileInputStream fis = null;
//                fis=openFileInput(ss);
//                Toast.makeText(getApplicationContext(),"1",Toast.LENGTH_LONG).show();
//
//                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//                byte[] buffer = new byte[1024];
//                int bytesRead;
//                Toast.makeText(getApplicationContext(),"2",Toast.LENGTH_LONG).show();
//
//                while ((bytesRead = fis.read(buffer)) != -1) {
//                    byteArrayOutputStream.write(buffer, 0, bytesRead);
//                }
//                Toast.makeText(getApplicationContext(),"3",Toast.LENGTH_LONG).show();
//
//                return byteArrayOutputStream.toByteArray();


            }
            catch (Exception e1)
            {
//                tv1.setText(e1+"========================================== =============================== ============================");
//                Toast.makeText(getApplicationContext(),"++="+e1,Toast.LENGTH_LONG).show();

            }



        }
        return byteArray;


    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent ik = new Intent(getApplicationContext(), view_job.class);
        startActivity(ik);
    }

}