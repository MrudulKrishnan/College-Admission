import email

from django.db import models

# Create your models here.
class login_table(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    type= models.CharField(max_length=100)

class user_table(models.Model):
    login=models.ForeignKey(login_table,on_delete=models.CASCADE)
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    dob=models.DateField()
    gender=models.CharField(max_length=25)
    place= models.CharField(max_length=100)
    post= models.CharField(max_length=100)
    phoneno=models.BigIntegerField()
    pin=models.BigIntegerField()
    email= models.CharField(max_length=100)
    photo=models.FileField()
    rank = models.CharField(max_length=50)
    mark = models.CharField(max_length=50)


class expert_table(models.Model):
    login = models.ForeignKey(login_table, on_delete=models.CASCADE)
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    dob = models.DateField()
    gender = models.CharField(max_length=25)
    place = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    pin = models.IntegerField()
    phoneno = models.BigIntegerField()
    email = models.CharField(max_length=100)
    photo = models.FileField()

class online_course_table(models.Model):
    expert= models.ForeignKey(expert_table, on_delete=models.CASCADE)
    course = models.CharField(max_length=100)
    details= models.CharField(max_length=100)
    duration = models.CharField(max_length=100)
    fee= models.BigIntegerField()
    date = models.DateField()

class notification_table(models.Model):
    notification = models.CharField(max_length=100)
    date = models.DateField()

class complaint_table(models.Model):
    user= models.ForeignKey(user_table, on_delete=models.CASCADE)
    complaint = models.CharField(max_length=100)
    date = models.DateField()
    reply= models.CharField(max_length=100)

class study_materials_table(models.Model):
    expert= models.ForeignKey(expert_table, on_delete=models.CASCADE)
    COURSE = models.ForeignKey(online_course_table, on_delete=models.CASCADE)
    studymaterials= models.CharField(max_length=100)
    file= models.FileField()
    details= models.CharField(max_length=100)

class tips_table(models.Model):
    expert = models.ForeignKey(expert_table, on_delete=models.CASCADE)
    tips= models.CharField(max_length=100)
    details = models.CharField(max_length=100)

class interview_vedios_table(models.Model):
    expert= models.ForeignKey(expert_table, on_delete=models.CASCADE)
    date = models.DateField()
    vedio= models.FileField()
    details= models.CharField(max_length=100)

class trends_in_table(models.Model):
    expert= models.ForeignKey(expert_table, on_delete=models.CASCADE)
    date = models.DateField()
    trends= models.CharField(max_length=100)
    details = models.CharField(max_length=100)

class agency_table(models.Model):
    login = models.ForeignKey(login_table, on_delete=models.CASCADE)
    agencyname = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    photo = models.FileField()
    post = models.CharField(max_length=100)
    phoneno = models.BigIntegerField()
    pin = models.BigIntegerField()
    email = models.CharField(max_length=100)


class job_table(models.Model):
    agency= models.ForeignKey(agency_table, on_delete=models.CASCADE)
    job = models.CharField(max_length=100)
    requirements= models.CharField(max_length=100)
    jobdetails = models.CharField(max_length=100)
    vaccancy=models.CharField(max_length=100)
    date = models.DateField()

class test_table(models.Model):
    job= models.ForeignKey(job_table, on_delete=models.CASCADE)
    question= models.CharField(max_length=100)
    answers= models.CharField(max_length=100)
    option1 = models.CharField(max_length=100)
    option2 = models.CharField(max_length=100)
    option3 = models.CharField(max_length=100)
    option4 = models.CharField(max_length=100)


class jobrequest_table(models.Model):
    job= models.ForeignKey(job_table, on_delete=models.CASCADE)
    user = models.ForeignKey(user_table, on_delete=models.CASCADE)
    status= models.CharField(max_length=100)
    resume = models.CharField(max_length=100)
    date = models.DateField()
    time = models.CharField(max_length=100)


class interview_info_table(models.Model):
    jobrequest= models.ForeignKey(jobrequest_table, on_delete=models.CASCADE)
    place= models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    date = models.DateField()


class attend_exam_table(models.Model):
    question= models.ForeignKey(test_table, on_delete=models.CASCADE)
    answers= models.CharField(max_length=100)
    user = models.ForeignKey(user_table, on_delete=models.CASCADE)
    marks= models.CharField(max_length=100)
    date = models.DateField()


class college_table(models.Model):
    login = models.ForeignKey(login_table, on_delete=models.CASCADE)
    collegename = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    phoneno = models.BigIntegerField()
    pin = models.BigIntegerField()
    email = models.CharField(max_length=100)


class course_details(models.Model):
    course= models.CharField(max_length=100)
    department= models.CharField(max_length=100)
    duration = models.CharField(max_length=100)


class addmission_details_table(models.Model):
    college=models.ForeignKey(college_table,on_delete=models.CASCADE)
    courses=models.ForeignKey(course_details,on_delete=models.CASCADE)
    rank= models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    marks= models.CharField(max_length=100)
    year=models.IntegerField()

class CollegeRequest(models.Model):
    ADMISSION=models.ForeignKey(addmission_details_table,on_delete=models.CASCADE)
    USER=models.ForeignKey(user_table,on_delete=models.CASCADE)
    date = models.DateField()
    status = models.CharField(max_length=20)