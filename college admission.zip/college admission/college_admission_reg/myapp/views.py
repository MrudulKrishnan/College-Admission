import json
from datetime import datetime

from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage
from django.db.models import Sum, Count
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

# Create your views here.
from myapp.models import *


def login(request):
    return render(request,'login_index.html')

def logout(request):
    auth.logout(request)
    return render(request,'login_index.html')

def login_post(request):
    try:
        uname=request.POST["textfield"]
        password=request.POST["textfield2"]
        q=login_table.objects.get(username=uname,password=password)
        if q.type=="admin":
            auth_obj = auth.authenticate(username="admin", password="admin")
            if auth_obj is not None:
                auth.login(request, auth_obj)
            return HttpResponse('''<script>alert('Login Success');window.location='/adminhome'</script>''')
        elif q.type=="agency":
            auth_obj = auth.authenticate(username="admin", password="admin")
            if auth_obj is not None:
                auth.login(request, auth_obj)

            request.session["lid"] = q.id
            return HttpResponse('''<script>alert('agency Login Success');window.location='/agency_home'</script>''')
        elif q.type == "expert":
            auth_obj = auth.authenticate(username="admin", password="admin")
            if auth_obj is not None:
                auth.login(request, auth_obj)

            request.session["lid"] = q.id
            return HttpResponse('''<script>alert('expert Login Success');window.location='/experthome'</script>''')
        elif q.type == "college":
            auth_obj = auth.authenticate(username="admin", password="admin")
            if auth_obj is not None:
                auth.login(request, auth_obj)

            request.session["lid"]=q.id
            return HttpResponse('''<script>alert('college Login Success');window.location='/collegehome'</script>''')

        else:
            return HttpResponse('''<script>alert('Invalid');window.location='/'</script>''')
    except:
        return HttpResponse('''<script>alert('Error');window.location='/'</script>''')


@login_required(login_url="/")
def adminhome(request):
    return render(request,'admin/admin_index.html')


@login_required(login_url="/")
def add_agency(request):
    return render(request, 'admin/add agency.html')


@login_required(login_url="/")
def agency(request):
    anm=request.POST['textfield']
    pl=request.POST['textfield2']
    po=request.POST['textfield3']
    pn=request.POST['textfield4']
    ph=request.POST['textfield5']
    em=request.POST['textfield50']
    unm=request.POST['textfield6']
    pw=request.POST['textfield7']
    pt=request.FILES['file']

    fs=FileSystemStorage()
    fn=fs.save(pt.name,pt)

    ob=login_table()
    ob.username=unm
    ob.password=pw
    ob.type="agency"
    ob.save()

    oj=agency_table()
    oj.login=ob
    oj.agencyname=anm
    oj.place=pl
    oj.photo=fn
    oj.post=po
    oj.pin=pn
    oj.phoneno=ph
    oj.email=em
    oj.save()

    return HttpResponse('''<script>alert('Login Success');window.location='/manage_agency#about'</script>''')


@login_required(login_url="/")
def delete_agency(request, id):
    ob = login_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert('deleted successfully');window.location='/manage_agency#about'</script>''')


@login_required(login_url="/")
def edit_agency(request, id):
    ob = agency_table.objects.get(id=id)
    request.session['ag_id'] = id
    return render(request, 'admin/edit agency.html', {'val': ob})


@login_required(login_url="/")
def edit_agency_post(request):
    try:
        anm=request.POST['textfield']
        pl=request.POST['textfield2']
        po=request.POST['textfield3']
        pn=request.POST['textfield4']
        ph=request.POST['textfield5']
        em=request.POST['textfield50']
        pt=request.FILES['file']

        fs=FileSystemStorage()
        fn=fs.save(pt.name,pt)
        oj=agency_table.objects.get(id=request.session['ag_id'])
        oj.agencyname=anm
        oj.place=pl
        oj.photo=fn
        oj.post=po
        oj.pin=pn
        oj.phoneno=ph
        oj.email=em
        oj.save()
        return HttpResponse('''<script>alert('Login Success');window.location='/manage_agency#about'</script>''')
    except:
        anm = request.POST['textfield']
        pl = request.POST['textfield2']
        po = request.POST['textfield3']
        pn = request.POST['textfield4']
        ph = request.POST['textfield5']
        em = request.POST['textfield50']

        oj=agency_table.objects.get(id=request.session['ag_id'])
        oj.agencyname = anm
        oj.place = pl
        oj.post = po
        oj.pin = pn
        oj.phoneno = ph
        oj.email = em
        oj.save()
        return HttpResponse('''<script>alert('Login Success');window.location='/manage_agency#about'</script>''')


@login_required(login_url="/")
def agency_home(request):
    return render(request, 'agency/agency_index.html')


@login_required(login_url="/")
def interview(request):
    return render(request, 'agency/interview.html')


@login_required(login_url="/")
def view_profile_expert(request):
    ob = expert_table.objects.get(login_id=request.session['lid'])
    return render(request, 'expert/view profile.html', {'val': ob})


@login_required(login_url="/")
def manage_agency(request):
    ob=agency_table.objects.all()
    return render(request, 'admin/manage agency.html',{'val':ob})


@login_required(login_url="/")
def manage_agency_search(request):
    search = request.POST['textfield']
    ob=agency_table.objects.filter(agencyname__istartswith=search)
    return render(request, 'admin/manage agency.html',{'val':ob, 'search': search})



@login_required(login_url="/")
def interview_post(request):
    jbr=request.POST['textfield']
    pl=request.POST['textfield2']
    po=request.POST['textfield3']
    pn=request.POST['textfield4']
    ph=request.POST['textfield5']
    em=request.POST['textfield50']
    unm=request.POST['textfield6']
    pw=request.POST['textfield7']
    pt=request.FILES['file']

    fs=FileSystemStorage()
    fn=fs.save(pt.name,pt)

    ob=login_table()
    ob.username=unm
    ob.password=pw
    ob.type="Homepage"
    ob.save()

    oj=agency_table()
    oj.login=ob
    oj.agencyname=jbr
    oj.place=pl
    oj.photo=fn
    oj.post=po
    oj.pin=pn
    oj.phoneno=ph
    oj.email=em
    oj.save()
    return HttpResponse('''<script>alert('successfully added');window.location='/manage_agency#about'</script>''')


@login_required(login_url="/")
def interview(request):
    jqt = request.POST['textfield']
    pl = request.POST['textfield']
    dt = request.POST['textfield']
    st = request.POST['textfield']

    oj=interview_info_table()
    oj.jobrequest=jqt
    oj.place=pl
    oj.date=dt
    oj.status=st
    oj.save()
    return HttpResponse('''<script>alert('Question Added');window.location='/manage_interview_info#about'</script>''')


@login_required(login_url="/")
def notify(request):
    nt=request.POST['textfield']
    oj=notification_table()
    oj.notification=nt
    oj.date=datetime.today()
    oj.save()
    return HttpResponse('''<script>alert('Added');window.location='/adminhome'</script>''')


@login_required(login_url="/")
def send_notification(request):
    return render(request,'admin/send notification.html')


@login_required(login_url="/")
def manage_course(request):
    ob = course_details.objects.all()
    return render(request,'admin/manage course.html',{'val':ob})


@login_required(login_url="/")
def manage_course_search(request):
    search = request.POST['textfield']
    ob = course_details.objects.filter(course__istartswith=search)
    return render(request,'admin/manage course.html',{'val':ob, 'search': search})


@login_required(login_url="/")
def add_course(request):
    return render(request,'admin/add course.html')

@login_required(login_url="/")
def add_course_post(request):
    course = request.POST['textfield']
    department = request.POST['textfield2']
    duration = request.POST['textfield3']

    oj=course_details()
    oj.course=course
    oj.duration=duration
    oj.department=department
    oj.save()
    return HttpResponse('''<script>alert('course Added');window.location='/manage_course#about'</script>''')



@login_required(login_url="/")
def delete_course(request, id):
    ob = course_details.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert('course deleted');window.location='/manage_course#about'</script>''')

@login_required(login_url="/")
def edit_course(request, id):
    request.session['course_id'] = id
    ob = course_details.objects.get(id=id)
    return render(request,'admin/edit course.html', {'val': ob})

@login_required(login_url="/")
def edit_course_post(request):
    course = request.POST['textfield']
    department = request.POST['textfield2']
    duration = request.POST['textfield3']

    oj=course_details.objects.get(id=request.session['course_id'])
    oj.course=course
    oj.department=department
    oj.duration=duration
    oj.save()
    return HttpResponse('''<script>alert('course edited');window.location='/manage_course#about'</script>''')





@login_required(login_url="/")
def verify_user(request):
    ob=user_table.objects.all()
    return render(request,'admin/verify user.html',{'val':ob})


@login_required(login_url="/")
def acceptuser(request,id):
    ob=login_table.objects.get(id=id)
    ob.type='user'
    ob.save()
    return HttpResponse('''<script>alert('accepted');window.location='/verify_user#about'</script>''')


@login_required(login_url="/")
def rejectuser(request,id):
    ob=login_table.objects.get(id=id)
    ob.type='reject'
    ob.save()
    return HttpResponse('''<script>alert('rejected');window.location='/verify_user#about'</script>''')



@login_required(login_url="/")
def verify_college(request):
    ob=college_table.objects.all()
    return render(request,'admin/verify college.html',{'val':ob})


@login_required(login_url="/")
def accept_college(request,id):
    ob=login_table.objects.get(id=id)
    ob.type='college'
    ob.save()
    return HttpResponse('''<script>alert('accepted');window.location='/verify_college#about'</script>''')


@login_required(login_url="/")
def reject_college(request,id):
    ob=login_table.objects.get(id=id)
    ob.type='reject'
    ob.save()
    return HttpResponse('''<script>alert('rejected');window.location='/verify_college#about'</script>''')


@login_required(login_url="/")
def manage_expert(request):
    ob = expert_table.objects.all()
    return render(request,'admin/manage expert.html', {'val': ob})


@login_required(login_url="/")
def manage_expert_search(request):
    search = request.POST['textfield']
    ob = expert_table.objects.filter(firstname__istartswith=search)
    return render(request,'admin/manage expert.html', {'val': ob, 'search': search})


@login_required(login_url="/")
def add_expert(request):
    return render(request,'admin/add expert.html')


@login_required(login_url="/")
def add_expert_post(request):
    Firstname=request.POST['Firstname']
    Lastname=request.POST['Lastname']
    Gender=request.POST['radiobutton']
    DOB=request.POST['date']
    place=request.POST['textfield2']
    post=request.POST['textfield3']
    pin=request.POST['textfield4']
    phone=request.POST['textfield5']
    Email=request.POST['textfield50']
    username=request.POST['textfield6']
    password=request.POST['textfield7']
    photo=request.FILES['file']

    fs=FileSystemStorage()
    fn=fs.save(photo.name,photo)

    ob=login_table()
    ob.username=username
    ob.password=password
    ob.type="expert"
    ob.save()

    oj=expert_table()
    oj.login=ob
    oj.firstname=Firstname
    oj.lastname=Lastname
    oj.dob=DOB
    oj.gender=Gender
    oj.place=place
    oj.post=post
    oj.pin=pin
    oj.phoneno=phone
    oj.email=Email
    oj.photo=fn
    oj.save()
    return HttpResponse('''<script>alert('successfully added');window.location='/manage_expert#about'</script>''')


@login_required(login_url="/")
def delete_expert(request, id):
    ob = login_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert('successfully edited');window.location='/manage_expert#about'</script>''')


@login_required(login_url="/")
def edit_expert(request, id):
    request.session['e_id'] = id
    ob = expert_table.objects.get(id=id)
    return render(request,'admin/edit expert.html', {'val': ob, 'd': str(ob.dob) })



@login_required(login_url="/")
def edit_expert_post(request):
    try:
        Firstname=request.POST['Firstname']
        Lastname=request.POST['Lastname']
        Gender=request.POST['radiobutton']
        DOB=request.POST['date']
        place=request.POST['textfield2']
        post=request.POST['textfield3']
        pin=request.POST['textfield4']
        phone=request.POST['textfield5']
        Email=request.POST['textfield50']
        photo=request.FILES['file']
        fs=FileSystemStorage()
        fn=fs.save(photo.name,photo)

        oj=expert_table.objects.get(id=request.session['e_id'])
        oj.firstname=Firstname
        oj.lastname=Lastname
        oj.dob=DOB
        oj.gender=Gender
        oj.place=place
        oj.post=post
        oj.pin=pin
        oj.phoneno=phone
        oj.email=Email
        oj.photo=fn
        oj.save()
        return HttpResponse('''<script>alert('successfully edited');window.location='/manage_expert#about'</script>''')
    except:
        Firstname = request.POST['Firstname']
        Lastname = request.POST['Lastname']
        Gender = request.POST['radiobutton']
        DOB = request.POST['date']
        place = request.POST['textfield2']
        post = request.POST['textfield3']
        pin = request.POST['textfield4']
        phone = request.POST['textfield5']
        Email = request.POST['textfield50']

        oj = expert_table.objects.get(id=request.session['e_id'])
        oj.firstname = Firstname
        oj.lastname = Lastname
        oj.dob = DOB
        oj.gender = Gender
        oj.place = place
        oj.post = post
        oj.pin = pin
        oj.phoneno = phone
        oj.email = Email
        oj.save()
        return HttpResponse('''<script>alert('successfully edited');window.location='/manage_expert#about'</script>''')



@login_required(login_url="/")
def view_complaint(request):
    ob = complaint_table.objects.all()
    return render(request,'admin/view complaint.html',{'val':ob})


@login_required(login_url="/")
def view_complaint_agency(request):
    ob = complaint_table.objects.all()
    return render(request,'agency/view complaint.html',{'val':ob})


@login_required(login_url="/")
def view_complaint_search(request):
    search = request.POST['textfield']
    ob = complaint_table.objects.filter(date=search)
    return render(request,'admin/view complaint.html',{'val':ob, 'search': search})


@login_required(login_url="/")
def send_reply(request, id):
    request.session['c_id'] = id
    return render(request,'admin/send reply.html')


@login_required(login_url="/")
def comp_reply_post(request):
    reply = request.POST['textfield']
    ob = complaint_table.objects.get(id=request.session['c_id'])
    ob.reply = reply
    ob.save()
    return HttpResponse('''<script>alert('reply added');window.location='/view_complaint#about'</script>''')



@login_required(login_url="/")
def view_shortlist_ag(request):
    global i
    obb = job_table.objects.filter(agency__login__id=request.session['lid'])
    applyjob = jobrequest_table.objects.filter(job__agency__login__id=request.session['lid'])
    row = []
    stdlist = []

    for ij in applyjob:
        print("=========================12")
        jobid = ij.job.id
        if ij.user.id in stdlist:
            pass
        else:
            stdlist.append(ij.user.id)
            # for k in stdlist:
            # res=result_table.objects.filter(QUESTION_ID__JOB_ID=jobid)
            print(jobid)
            ques = attend_exam_table.objects.filter(question__job__id=jobid, user__id=ij.user.id).order_by('-marks')
            total = 0
            for i in ques:
                print("=========================134")

                print("----", i.marks)
                total = total + int(i.marks)

                a = {"sname": i.user.firstname + "" + i.user.lastname, "photo": i.user.photo, "totalscore": total,
                     "mark": i.marks, "job": ij.job.job, "date": ij.date, "resume": ij.resume, "status": ij.status,
                     "req_id": ij.id}
                row.append(a)
    return render(request, 'agency/View Ranking & Result.html', {'val': row, 'job': obb})



def view_shortlist_ag_search(request):
    job=request.POST['select']
    obb=job_table.objects.filter(agency__login__id=request.session['lid'])
    applyjob=jobrequest_table.objects.filter(job_id=job,job__agency__login__id=request.session['lid'])
    row=[]
    stdlist=[]

    for ij in applyjob:
        print("=========================12")
        jobid = ij.job.id
        if ij.user.id in stdlist:
            pass
        else:
            stdlist.append(ij.user.id)

        # for k in stdlist:
            # res=result_table.objects.filter(QUESTION_ID__JOB_ID=jobid)


            print(jobid)
            ques = attend_exam_table.objects.filter(question__job__id=jobid,user__id=ij.user.id).order_by('-marks')
            total = 0
            for i in ques:
                print("=========================134")

                print("----", i.marks)
                total = total + int(i.marks)

                a = {"sname": i.user.firstname + "" + i.user.lastname,"photo":i.user.photo,"totalscore": total,
                     "mark":i.marks, "job": ij.job.job, "date": ij.date, "resume": ij.resume}
                row.append(a)

    return render(request,'agency/View Ranking & Result.html',{'val':row, 'job':obb})
def send_shortlist(request, id):
    ob = jobrequest_table.objects.get(id=id)
    ob.status = "shortlisted"
    ob.save()
    return HttpResponse('''<script>alert('Shortlisted');window.location='/view_shortlist_ag#about'</script>''')



@login_required(login_url="/")
def manage_jobs(request):
    ob = job_table.objects.filter(agency__login__id=request.session['lid'])
    return render(request,'agency/manage jobs.html',{'val':ob})


@login_required(login_url="/")
def manage_jobs_search(request):
    search = request.POST['textfield']
    ob = job_table.objects.filter(agency__login__id=request.session['lid'], job__istartswith=search)
    return render(request,'agency/manage jobs.html',{'val':ob, 'search': search})


@login_required(login_url="/")
def add_jobs(request):
    return render(request,'agency/add jobs.html')

@login_required(login_url="/")
def jobs(request):
    jb = request.POST['textfield']
    jbd = request.POST['textfield2']
    rq = request.POST['textfield3']
    vc = request.POST['textfield4']

    oj=job_table()
    oj.job=jb
    oj.jobdetails=jbd
    oj.requirements=rq
    oj.vaccancy=vc
    oj.date = datetime.today()
    oj.agency=agency_table.objects.get(login__id=request.session["lid"])
    oj.save()
    return HttpResponse('''<script>alert('job Added');window.location='/manage_jobs#about'</script>''')



@login_required(login_url="/")
def delete_jobs(request, id):
    ob = job_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert('job deleted');window.location='/manage_jobs#about'</script>''')


@login_required(login_url="/")
def edit_jobs(request, id):
    request.session['job_id'] = id
    ob = job_table.objects.get(id=id)
    return render(request,'agency/edit jobs.html', {'val': ob})


@login_required(login_url="/")
def edit_jobs_post(request):
    jb = request.POST['textfield']
    jbd = request.POST['textfield2']
    rq = request.POST['textfield3']
    vc = request.POST['textfield4']

    oj=job_table.objects.get(id=request.session['job_id'])
    oj.job=jb
    oj.jobdetails=jbd
    oj.requirements=rq
    oj.vaccancy=vc
    oj.date = datetime.today()
    oj.agency=agency_table.objects.get(login__id=request.session["lid"])
    oj.save()
    return HttpResponse('''<script>alert('job edited');window.location='/manage_jobs#about'</script>''')


@login_required(login_url="/")
def verify_job_request(request, id):
    ob = jobrequest_table.objects.filter(job_id=id)
    return render(request, "agency/verify_job_request.html", {'val': ob})


@login_required(login_url="/")
def reject_job_request(request, id):
    ob = jobrequest_table.objects.get(id=id)
    ob.status="rejected"
    ob.save()
    return HttpResponse('''<script>alert('Request rejected');window.location='/manage_jobs#about'</script>''')


@login_required(login_url="/")
def accept_job_request(request, id):
    ob = jobrequest_table.objects.get(id=id)
    ob.status="accepted"
    ob.save()
    return HttpResponse('''<script>alert('Request accepted');window.location='/manage_jobs#about'</script>''')


@login_required(login_url="/")
def add_placement_details(request):
    ob = jobrequest_table.objects.all()
    return render(request,'agency/add placement details.html',{'val':ob})


@login_required(login_url="/")
def add_test(request):
    ob=job_table.objects.filter(agency__login__id=request.session['lid'])
    return render(request,'agency/add test.html',{'val':ob})


@login_required(login_url="/")
def select_job(request):
    ob = job_table.objects.filter(agency__login_id=request.session['lid'])
    return render(request,'agency/select_job.html',{'val':ob})


@login_required(login_url="/")
def manage_test(request, id):
    request.session['job_id'] = id
    ob = test_table.objects.filter(job_id=id)
    return render(request,'agency/manage test.html',{'val':ob})


@login_required(login_url="/")
def tests(request):
    qn = request.POST['textfield']
    an = request.POST['textfield6']
    op1 = request.POST['textfield2']
    op2 = request.POST['textfield3']
    op3 = request.POST['textfield4']
    op4 = request.POST['textfield5']

    oj=test_table()
    oj.question=qn
    oj.answers=an
    oj.option1=op1
    oj.option2=op2
    oj.option3=op3
    oj.option4=op4
    oj.option4=op4
    oj.job=job_table.objects.get(id=request.session['job_id'])
    oj.save()
    return HttpResponse('''<script>alert('Question Added');window.location='/manage_jobs#about'</script>''')



@login_required(login_url="/")
def delete_test(request,id):
    ob1=test_table.objects.get(id=id)
    ob1.delete()
    return HttpResponse('''<script>alert('test_deleted');window.location='/manage_jobs#about'</script>''')


@login_required(login_url="/")
def edit_test(request,id):
    ob1=test_table.objects.get(id=id)
    request.session['t_id'] = id
    ob=job_table.objects.filter(agency__login__id=request.session['lid'])
    return render(request,'agency/edit test.html',{'val':ob, 'val1': ob1})


@login_required(login_url="/")
def edit_tests(request):
    qn = request.POST['textfield']
    an = request.POST['textfield6']
    op1 = request.POST['textfield2']
    op2 = request.POST['textfield3']
    op3 = request.POST['textfield4']
    op4 = request.POST['textfield5']

    oj=test_table.objects.get(id=request.session['t_id'])
    oj.question=qn
    oj.answers=an
    oj.option1=op1
    oj.option2=op2
    oj.option3=op3
    oj.option4=op4
    oj.option4=op4
    oj.job=job_table.objects.get(id=request.session['job_id'])
    oj.save()
    return HttpResponse('''<script>alert('Question edited');window.location='/manage_jobs#about'</script>''')


@login_required(login_url="/")
def shortlisted_request(request):
    ob = jobrequest_table.objects.filter(job__agency__login_id=request.session['lid'], status="shortlisted")
    return render(request,'agency/shortlisted_request.html',{'val':ob})


@login_required(login_url="/")
def add_interview_info(request, id):
    request.session['req_id'] = id
    return render(request,'agency/add interview info.html')


@login_required(login_url="/")
def add_interview_info_post(request):
    place = request.POST['textfield']
    date = request.POST['textfield2']

    ob = interview_info_table()
    ob.jobrequest = jobrequest_table.objects.get(id=request.session['req_id'])
    ob.place = place
    ob.date = date
    ob.status = "pending"
    ob.save()

    ob1 = jobrequest_table.objects.get(id=request.session['req_id'])
    ob1.status = "assigned"
    ob1.save()
    return HttpResponse('''<script>alert('interview added');window.location='/shortlisted_request#about'</script>''')



@login_required(login_url="/")
def interview_info(request):
    ob = interview_info_table.objects.filter(jobrequest__job__agency__login_id=request.session['lid'], status="pending" )
    return render(request,'agency/manage interview info.html',{'val':ob})


def placement(request, id):
    ob = interview_info_table.objects.get(id=id)
    x=jobrequest_table.objects.get(id=ob.jobrequest.id)
    x.status = "placed"
    x.save()
    ob.status = "placed"
    ob.save()

    return HttpResponse('''<script>alert('Successfully placed');window.location='/interview_info#about'</script>''')


def placement_reject(request, id):
    ob = interview_info_table.objects.get(id=id)
    ob.status = "rejected"
    ob.save()
    x=jobrequest_table.objects.get(id=ob.jobrequest.id)
    x.status = "placement rejected"
    x.save()

    return HttpResponse('''<script>alert('Successfully placed');window.location='/interview_info#about'</script>''')



@login_required(login_url="/")
def verify_interview(request):
    return render(request,'agency/verify interview.html')


@login_required(login_url="/")
def view_job_etails_and_forward(request):
    return render(request,'agency/view job details and forward.html')


@login_required(login_url="/")
def view_notification_ag(request):
    ob = notification_table.objects.all()
    return render(request,'agency/view notification.html', {'val': ob})


@login_required(login_url="/")
def view_profile(request):
    ob = agency_table.objects.get(login__id=request.session["lid"])
    return render(request,'agency/view profile.html',{'val': ob})


@login_required(login_url="/")
def collegehome(request):
    return render(request,'college/college_index.html')


@login_required(login_url="/")
def add_addmission_details(request):
    ob = course_details.objects.all()
    return render(request,'college/add addmission details.html', {'val': ob})


@login_required(login_url="/")
def details(request):
    crs=request.POST['select1']
    rk=request.POST['textfield3']
    ty=request.POST['select2']
    mr=request.POST['textfield2']
    yr=request.POST['textfield5']

    ob = addmission_details_table()
    ob.college = college_table.objects.get(login_id=request.session['lid'])
    ob.courses = course_details.objects.get(id=crs)
    ob.rank=rk
    ob.type=ty
    ob.marks=mr
    ob.year=yr
    ob.save()
    return HttpResponse('''<script>alert('addmission details added');window.location='/manage_addmission_details#about'</script>''')


@login_required(login_url="/")
def edit_admission(request,id):
    ob = course_details.objects.all()
    ob1=addmission_details_table.objects.get(id=id)
    return render(request,'college/edit addmission details.html',{'val1':ob1, 'val': ob})


@login_required(login_url="/")
def addmission_details(request):
    crs=request.POST['select1']
    rk=request.POST['textfield3']
    ty=request.POST['select2']
    mr=request.POST['textfield2']
    yr=request.POST['textfield5']

    ob = addmission_details_table()
    ob.college = college_table.objects.get(login_id=request.session['lid'])
    ob.courses = course_details.objects.get(id=crs)
    ob.rank=rk
    ob.type=ty
    ob.marks=mr
    ob.year=yr
    ob.save()
    return HttpResponse('''<script>alert('addmission details added');window.location='/manage_addmission_details#about'</script>''')



@login_required(login_url="/")
def addmission_history(request):
    ob=addmission_details_table.objects.filter(college__login_id=request.session["lid"])
    return render(request,'college/addmission history.html',{'val':ob})


@login_required(login_url="/")
def manage_addmission_details(request):
    ob = addmission_details_table.objects.filter(college__login=request.session["lid"])
    return render(request,'college/manage addmission details.html', {'val': ob})


@login_required(login_url="/")
def manage_addmission_details_delete(request,id):
    ob = addmission_details_table.objects.get(id=id).delete()
    return HttpResponse('''<script>alert('deleted');window.location='/manage_addmission_details#about'</script>''')


@login_required(login_url="/")
def view_job_details_and_forward(request):
    ob = job_table.objects.all()
    return render(request, 'college/view job details and forward.html', {'val': ob})



@login_required(login_url="/")
def view_notification(request):
    ob = notification_table.objects.all()
    return render(request,'college/view notification.html', {'val': ob})


@login_required(login_url="/")
def view_placement_details(request):
    user_id = []
    job_id = []
    ob=interview_info_table.objects.filter(jobrequest__job__agency__login_id=request.session['lid'], status="placed")
    # for i in ob:
    #     user_id.append(i.jobrequest.user.id)
    #     job_id.append(i.jobrequest.job.id)
    #
    # ob1 = attend_exam_table.objects.get(user_id__in=user_id, question__job_id__in=job_id)
    return render(request,'agency/view placement details.html',{'val':ob})


@login_required(login_url="/")
def view_marks(request, id):
    ob=interview_info_table.objects.get(id=id)
    ob1 = attend_exam_table.objects.filter(user_id=ob.jobrequest.user.id, jobrequest__job__job=ob.question__job__job)
    return render(request,'college/view placement details.html',{'val':ob})


@login_required(login_url="/")
def view_shortlist(request):
    st_id = []
    print("%%%%%%%%%%%college id", request.session['lid'])
    clg_obj = CollegeRequest.objects.filter(ADMISSION__college__login_id=request.session['lid'], status="accepted")
    print("%%%%%%%%%%%college obj", clg_obj)
    for i in clg_obj:
        st_id.append(i.USER.id)

    ob = jobrequest_table.objects.filter(user_id__in=st_id, status="shortlisted")
    return render(request,'college/view shortlist.html',{'val':ob})


@login_required(login_url="/")
def view_student_request(request):
    ob=CollegeRequest.objects.filter(ADMISSION__college__login=request.session["lid"])
    ob1 = course_details.objects.all()
    return render(request,'college/view student request.html',{'val':ob, 'val1': ob1})


@login_required(login_url="/")
def view_job_question(request,jobid):
    ob=test_table.objects.filter(job=jobid)
    return render(request,'college/job_questions.html',{"data":ob})


@login_required(login_url="/")
def accept_request(request,id):
    ob =CollegeRequest.objects.get(id=id)
    ob.status = "accepted"
    ob.save()
    return HttpResponse('''<script>alert('Accepted');window.location='/view_student_request#about'</script>''')


@login_required(login_url="/")
def reject_request(request,id):
    ob =CollegeRequest.objects.get(id=id)
    ob.status = "rejected"
    ob.save()
    return HttpResponse('''<script>alert('Rejected');window.location='/view_student_request#about'</script>''')


@login_required(login_url="/")
def view_placement_details_clg(request):
    st_id = []
    print("%%%%%%%%%%%college id", request.session['lid'])
    clg_obj = CollegeRequest.objects.filter(ADMISSION__college__login_id=request.session['lid'], status="accepted")
    print("%%%%%%%%%%%college obj", clg_obj)
    for i in clg_obj:
        st_id.append(i.USER.id)

    ob = interview_info_table.objects.filter(jobrequest__user_id__in=st_id, status="placed")

    return render(request,'college/view placement details.html',{'val':ob})


# //////////////////////// expert //////////////////////////////////////////

@login_required(login_url="/")
def experthome(request):
    return render(request,'expert/expert_index.html')


@login_required(login_url="/")
def manage_online_course(request):
    ob = online_course_table.objects.filter(expert__login_id=request.session['lid'])
    return render(request,'expert/manage online course.html',{'val': ob})


@login_required(login_url="/")
def manage_online_course_search(request):
    search = request.POST['textfield']
    ob = online_course_table.objects.filter(expert__login_id=request.session['lid'], course__istartswith=search)
    return render(request,'expert/manage online course.html',{'val': ob, 'search': search})


@login_required(login_url="/")
def add_online_course(request):
    return render(request,'expert/add online course.html')


@login_required(login_url="/")
def add_online_course_post(request):
    course = request.POST['textfield']
    details = request.POST['textfield2']
    duration = request.POST['textfield3']
    fee = request.POST['textfield4']

    ob = online_course_table()
    ob.expert = expert_table.objects.get(login_id=request.session['lid'])
    ob.course = course
    ob.details = details
    ob.duration = duration
    ob.fee = fee
    ob.date = datetime.now()
    ob.save()
    return HttpResponse('''<script>alert('online course added');window.location='/manage_online_course#about'</script>''')



@login_required(login_url="/")
def delete_online_course(request, id):
    ob = online_course_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert('online course deleted');window.location='/manage_online_course#about'</script>''')


@login_required(login_url="/")
def edit_online_course(request, id):
    request.session['online_id'] = id
    ob = online_course_table.objects.get(id=id)
    return render(request,'expert/edit online course.html', {'val': ob})


@login_required(login_url="/")
def edit_online_course_post(request):
    course = request.POST['textfield']
    details = request.POST['textfield2']
    duration = request.POST['textfield3']
    fee = request.POST['textfield4']

    ob = online_course_table.objects.get(id=request.session['online_id'])
    ob.expert = expert_table.objects.get(login_id=request.session['lid'])
    ob.course = course
    ob.details = details
    ob.duration = duration
    ob.fee = fee
    ob.date = datetime.now()
    ob.save()
    return HttpResponse('''<script>alert('online course edited');window.location='/manage_online_course#about'</script>''')



@login_required(login_url="/")
def manage_study_materials(request):
    ob = study_materials_table.objects.filter(expert__login_id=request.session['lid'])
    return render(request,'expert/manage study materials.html', {'val': ob})


@login_required(login_url="/")
def manage_study_materials_search(request):
    search = request.POST['textfield']
    ob = study_materials_table.objects.filter(expert__login_id=request.session['lid'], studymaterials__istartswith=search)
    return render(request,'expert/manage study materials.html', {'val': ob, 'search': search})


@login_required(login_url="/")
def add_study_materials(request):
    ob = online_course_table.objects.filter(expert__login_id=request.session['lid'])
    return render(request,'expert/add study materials.html', {'val': ob})


@login_required(login_url="/")
def add_study_materials_post(request):
    material = request.POST['textfield']
    course = request.POST['select']
    file = request.FILES['file']
    fss = FileSystemStorage()
    file_fss = fss.save(file.name, file)
    details = request.POST['textfield2']

    ob = study_materials_table()
    ob.expert = expert_table.objects.get(login_id=request.session['lid'])
    ob.studymaterials = material
    ob.COURSE = online_course_table.objects.get(id=course)
    ob.file = file_fss
    ob.details = details
    ob.save()
    return HttpResponse('''<script>alert('Materials added');window.location='/manage_study_materials#about'</script>''')


@login_required(login_url="/")
def delete_study_materials(request, id):
    ob = study_materials_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert('Materials deleted');window.location='/manage_study_materials#about'</script>''')



@login_required(login_url="/")
def edit_study_materials(request, id):
    request.session['m_id'] = id
    ob = study_materials_table.objects.get(id=id)
    return render(request,'expert/edit study materials.html', {'val': ob})


@login_required(login_url="/")
def edit_study_materials_post(request):
    try:
        material = request.POST['textfield']
        file = request.FILES['file']
        fss = FileSystemStorage()
        file_fss = fss.save(file.name, file)
        details = request.POST['textfield2']

        ob = study_materials_table.objects.get(id=request.session['m_id'])
        ob.expert = expert_table.objects.get(login_id=request.session['lid'])
        ob.studymaterials = material
        ob.file = file_fss
        ob.details = details
        ob.save()
        return HttpResponse('''<script>alert('Materials edited');window.location='/manage_study_materials#about'</script>''')
    except:
        material = request.POST['textfield']
        details = request.POST['textfield2']

        ob = study_materials_table.objects.get(id=request.session['m_id'])
        ob.expert = expert_table.objects.get(login_id=request.session['lid'])
        ob.studymaterials = material
        ob.details = details
        ob.save()
        return HttpResponse('''<script>alert('Materials edited');window.location='/manage_study_materials#about'</script>''')


@login_required(login_url="/")
def manage_interview_video(request):
    ob = interview_vedios_table.objects.filter(expert__login_id=request.session['lid'])
    return render(request,'expert/manage interview video.html', {'val': ob})


@login_required(login_url="/")
def add_interview_video(request):
    return render(request,'expert/add interview video.html')


@login_required(login_url="/")
def add_interview_video_post(request):
    video = request.FILES['file']
    fss = FileSystemStorage()
    video_file = fss.save(video.name, video)
    details = request.POST['textfield2']

    ob = interview_vedios_table()
    ob.expert = expert_table.objects.get(login_id=request.session['lid'])
    ob.vedio = video_file
    ob.details = details
    ob.date = datetime.now()
    ob.save()
    return HttpResponse('''<script>alert('Video added');window.location='/manage_interview_video#about'</script>''')


@login_required(login_url="/")
def delete_interview_video(request, id):
    ob = interview_vedios_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert('Video deleted');window.location='/manage_interview_video#about'</script>''')

@login_required(login_url="/")
def edit_interview_video(request, id):
    ob = interview_vedios_table.objects.get(id=id)
    request.session['v_id'] = id
    return render(request,'expert/edit interview video.html', {'val': ob})


@login_required(login_url="/")
def edit_interview_video_post(request):
    try:
        video = request.FILES['file']
        fss = FileSystemStorage()
        video_file = fss.save(video.name, video)
        details = request.POST['textfield2']

        ob = interview_vedios_table.objects.get(id=request.session['v_id'])
        ob.expert = expert_table.objects.get(login_id=request.session['lid'])
        ob.vedio = video_file
        ob.details = details
        ob.date = datetime.now()
        ob.save()
        return HttpResponse('''<script>alert('Video edited');window.location='/manage_interview_video#about'</script>''')
    except:
        details = request.POST['textfield2']
        ob = interview_vedios_table.objects.get(id=request.session['v_id'])
        ob.expert = expert_table.objects.get(login_id=request.session['lid'])
        ob.details = details
        ob.date = datetime.now()
        ob.save()
        return HttpResponse('''<script>alert('Video edited');window.location='/manage_interview_video#about'</script>''')


@login_required(login_url="/")
def add_trend_in_industry(request):
    return render(request,'expert/add trend in industry.html')


@login_required(login_url="/")
def add_trends_post(request):
    trends = request.POST['textfield']
    details = request.POST['textfield2']

    ob = trends_in_table()
    ob.expert = expert_table.objects.get(login_id=request.session['lid'])
    ob.trends = trends
    ob.details = details
    ob.date = datetime.now()
    ob.save()
    return HttpResponse('''<script>alert('Trend added');window.location='/experthome'</script>''')


@login_required(login_url="/")
def view_notification_exp(request):
    ob = notification_table.objects.all()
    return render(request,'expert/view notification.html', {'val': ob})


@login_required(login_url="/")
def manage_tips(request):
    ob = tips_table.objects.filter(expert__login_id=request.session['lid'])
    return render(request,'expert/manage tips.html', {'val': ob})


@login_required(login_url="/")
def manage_tips_search(request):
    search = request.POST['textfield']
    ob = tips_table.objects.filter(expert__login_id=request.session['lid'], tips__icontains=search)
    return render(request,'expert/manage tips.html', {'val': ob, 'search':search})


@login_required(login_url="/")
def add_tips(request):
    return render(request,'expert/add tips.html')


@login_required(login_url="/")
def add_tips_post(request):
    tips = request.POST['textfield']
    details = request.POST['textfield2']

    ob = tips_table()
    ob.expert = expert_table.objects.get(login_id=request.session['lid'])
    ob.tips = tips
    ob.details = details
    ob.save()
    return HttpResponse('''<script>alert('Tip added');window.location='/manage_tips#about'</script>''')


@login_required(login_url="/")
def delete_tips(request, id):
    ob = tips_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert('Tip delted');window.location='/manage_tips#about'</script>''')


@login_required(login_url="/")
def edit_tips(request, id):
    ob = tips_table.objects.get(id=id)
    request.session['tip_id'] = id
    return render(request,'expert/edit tips.html', {'val': ob})


@login_required(login_url="/")
def edit_tips_post(request):
    tips = request.POST['textfield']
    details = request.POST['textfield2']

    ob = tips_table.objects.get(id=request.session['tip_id'])
    ob.expert = expert_table.objects.get(login_id=request.session['lid'])
    ob.tips = tips
    ob.details = details
    ob.save()
    return HttpResponse('''<script>alert('Tip edit');window.location='/manage_tips#about'</script>''')


def college_reg(request):
    return render(request, "reg_index.html")


def college_reg_post(request):
    name = request.POST['textfield']
    place = request.POST['textfield2']
    post = request.POST['textfield3']
    pin = request.POST['textfield4']
    phone = request.POST['textfield5']
    email = request.POST['textfield50']
    username = request.POST['textfield6']
    password = request.POST['textfield7']

    ob = login_table()
    ob.username = username
    ob.password = password
    ob.type = "pending"
    ob.save()

    ob1 = college_table()
    ob1.collegename = name
    ob1.place = place
    ob1.post = post
    ob1.pin = pin
    ob1.phoneno = phone
    ob1.email = email
    ob1.login = ob
    ob1.save()
    return HttpResponse('''<script>alert('registration successfully complated');window.location='/'</script>''')






# //////////////////////////////// webservice /////////////////////////////////////////


def login_code_and(request):
    username = request.POST['username']
    password = request.POST['password']
    try:
        users = login_table.objects.get(username=username, password=password)
        if users is None:
            data = {"task": "invalid"}

        elif users.type == "user":
            data = {"task": "user", "id": users.id, "type": users.type}
            r = json.dumps(data)
            return HttpResponse(r)
        elif users.type == "tailershop":
            data = {"task": "tailor", "id": users.id, "type": users.type}
            r = json.dumps(data)
            return HttpResponse(r)
        else:
            data = {"task": "valid", "id": users.id, "type": users.type}
            r = json.dumps(data)
            return HttpResponse(r)
    except:
        data = {"task": "invalid"}
        r = json.dumps(data)
        print(r)
        return HttpResponse(r)



def user_register(request):
    print("r^^^^^^^^^^", request.POST)
    firstname = request.POST['firstname']
    lastname = request.POST['lastname']
    dob = request.POST['dob']
    gender = request.POST['gender']
    place = request.POST['place']
    post_office = request.POST['post']
    pin_code = request.POST['pin']
    phone = request.POST['phone']
    email = request.POST['email']
    photo = request.FILES['photo']
    fss = FileSystemStorage()
    photo_file = fss.save(photo.name, photo)
    rank = request.POST['rank']
    mark = request.POST['mark']
    username = request.POST['username']
    password = request.POST['password']
    u_list = []
    obj = login_table.objects.all()
    for i in obj:
        u_list.append(i.username)
    if username in u_list:
        data = {"task": "invalid"}
        r = json.dumps(data)
        return HttpResponse(r)
    lob = login_table()
    lob.username = username
    lob.password = password
    lob.type = 'pending'
    lob.save()

    user_obj = user_table()
    user_obj.firstname = firstname
    user_obj.lastname = lastname
    user_obj.gender = gender
    user_obj.dob = dob
    user_obj.place = place
    user_obj.post = post_office
    user_obj.pin = pin_code
    user_obj.phoneno = phone
    user_obj.email = email
    user_obj.photo = photo_file
    user_obj.rank = rank
    user_obj.mark = mark
    user_obj.login = lob
    user_obj.save()
    data = {"task": "success"}
    r = json.dumps(data)
    return HttpResponse(r)


def send_complaint(request):
    complaints = request.POST["complaint"]
    u_id = request.POST["lid"]
    date = datetime.now()
    reply = "waiting"
    complaint_obj = complaint_table()
    complaint_obj.complaint = complaints
    complaint_obj.date = date
    complaint_obj.reply = reply
    complaint_obj.user = user_table.objects.get(login_id=u_id)
    complaint_obj.save()
    data = {'task': 'success'}
    r = json.dumps(data)
    return HttpResponse(r)


def complaints_reply(request):
    user_id = request.POST['lid']
    print("****************", user_id)
    complaint_obj = complaint_table.objects.filter(user__login_id=user_id)
    data = []
    for i in complaint_obj:
        row = {'complaint': i.complaint, 'reply': i.reply, 'date': str(i.date)}
        data.append(row)
    r = json.dumps(data)
    return HttpResponse(r)


def and_view_job(request):
    user_id = request.POST['lid']
    print("****************", user_id)
    job_list = []
    jobreq_obj = jobrequest_table.objects.filter(user__login_id=user_id)
    for i in jobreq_obj:
        job_list.append(i.job.id)
    job_obj = job_table.objects.exclude(id__in=job_list)
    data = []
    for i in job_obj:
        row = {'job': i.job, 'job_details': i.jobdetails, 'requirements': i.requirements, 'vaccancy': i.vaccancy,
               'date': str(i.date), 'job_id': i.id}
        data.append(row)
    r = json.dumps(data)
    return HttpResponse(r)


def and_job_request_status(request):
    user_id = request.POST['lid']
    print("****************", user_id)
    job_obj = jobrequest_table.objects.filter(user__login_id=user_id)
    data = []
    for i in job_obj:
        row = {'job': i.job.job, 'job_details': i.job.jobdetails, 'requirements': i.job.requirements, 'vaccancy': i.job.vaccancy,
               'date': str(i.date), 'job_id': i.job.id, 'status': i.status}
        data.append(row)
    r = json.dumps(data)
    return HttpResponse(r)


def and_view_shortlist(request):
    user_lid = request.POST['lid']
    print("****************", user_lid)
    job_obj = jobrequest_table.objects.filter(user__login_id=user_lid, status="shortlisted")
    data = []
    for i in job_obj:
        row = {'agency': i.job.agency.agencyname,'job': i.job.job, 'requirements': i.job.requirements,
               'jobdetails': i.job.jobdetails}
        data.append(row)
    r = json.dumps(data)
    return HttpResponse(r)


def and_view_interview_info(request):
    user_lid = request.POST['lid']
    print("****************", user_lid)
    job_obj = interview_info_table.objects.filter(jobrequest__user__login_id=user_lid).exclude(status="placed")
    data = []
    for i in job_obj:
        row = {'agency': i.jobrequest.job.agency.agencyname,'job': i.jobrequest.job.job, 'requirements': i.jobrequest.job.requirements,
               'job_details': i.jobrequest.job.jobdetails, 'place': i.place, 'date':str(i.date), 'status': i.status}
        data.append(row)
    r = json.dumps(data)
    print("dataaaaa", data)
    return HttpResponse(r)


def and_view_placement_details(request):
    user_lid = request.POST['lid']
    print("****************", user_lid)
    job_obj = interview_info_table.objects.filter(jobrequest__user__login_id=user_lid, status="placed")
    data = []
    for i in job_obj:
        row = {'agency': i.jobrequest.job.agency.agencyname,'job': i.jobrequest.job.job, 'requirements': i.jobrequest.job.requirements,
               'jobdetails': i.jobrequest.job.jobdetails}
        data.append(row)
    r = json.dumps(data)
    print("dataaaaa", data)
    return HttpResponse(r)


def and_view_online_courses(request):
    user_lid = request.POST['lid']
    print("****************", user_lid)
    course_obj = online_course_table.objects.all()
    data = []
    for i in course_obj:
        row = {'expert': i.expert.firstname + " " + i.expert.lastname,'course': i.course, 'details': i.details, 'duration': i.duration,
               'fee': i.fee, 'course_id': i.id}
        data.append(row)
    r = json.dumps(data)
    print("dataaaaa", data)
    return HttpResponse(r)


def and_view_study_materials(request):
    user_lid = request.POST['lid']
    course_id = request.POST['course_id']
    print("****************", user_lid)
    course_obj = study_materials_table.objects.filter(COURSE__id=course_id)
    data = []
    for i in course_obj:
        row = {'expert': i.expert.firstname + " " + i.expert.lastname,'studymaterials': i.studymaterials, 'file': str(i.file.url), 'details': i.details}
        data.append(row)
    r = json.dumps(data)
    print("dataaaaa", data)
    return HttpResponse(r)


def and_view_interview_videos(request):
    user_lid = request.POST['lid']
    print("****************", user_lid)
    course_obj = interview_vedios_table.objects.all()
    data = []
    for i in course_obj:
        row = {'video': str(i.vedio.url),'details': i.details}
        data.append(row)
    r = json.dumps(data)
    print("dataaaaa", data)
    return HttpResponse(r)


def and_view_trends(request):
    user_lid = request.POST['lid']
    print("****************", user_lid)
    course_obj = trends_in_table.objects.all()
    data = []
    for i in course_obj:
        row = {'trends': str(i.trends),'details': i.details}
        data.append(row)
    r = json.dumps(data)
    print("dataaaaa", data)
    return HttpResponse(r)


def add_score(request):
    lid = request.POST['lid']
    qid = request.POST['qid']
    ans=request.POST['ans']
    res=request.POST['res']
    print("****************", request.POST)
    ob=test_table.objects.get(id=qid)
    eid=ob.job
    p=test_table.objects.filter(job=eid)
    print(len(p))
    q=attend_exam_table.objects.filter(user__login_id=lid,question__job_id=eid, date=datetime.today())
    print(len(q))
    if len(p)==len(q):
        return JsonResponse({'task':'invalid'})
    # ob=score_table.objects.filter(student__Login__id=lid,date=datetime.datetime.today())
    # if len(ob)==0:
    else:
        obb=attend_exam_table()
        obb.user=user_table.objects.get(login_id=lid)
        obb.question=test_table.objects.get(id=qid)
        obb.answers=ans
        obb.date = datetime.today()
        obb.marks=res
        obb.save()
        return JsonResponse({'task':'success'})


def view_test_status(request):
    user_id = request.POST['lid']
    job_obj = attend_exam_table.objects.filter(user__login_id=user_id).order_by('date')
    print("##########",job_obj)
    queryset = attend_exam_table.objects.filter(user__login_id=user_id).values('question__job__job','date').annotate(count=Sum('marks')).order_by('question__job')
    print(queryset,"***************************")
    data = []
    for i in queryset:
        row = {'crs': i['question__job__job'], 'score':i['count'], 'date': str(i['date'])}
        data.append(row)
    r = json.dumps(data)
    return HttpResponse(r)


def viewtest(request):
    j_id = request.POST['j_id']
    print("job_id***********", j_id)
    job_obj = test_table.objects.filter(job_id=j_id)
    data = []
    for i in job_obj:
        row = {'Question': i.question, 'answer': i.answers, 'Option1': i.option1, 'Option2': i.option2,
               'Option3': i.option3, 'Option4': i.option4, 'qid': i.id}
        data.append(row)
    r = json.dumps(data)
    print("&&&&&&&&&&&&&&", r)
    return HttpResponse(r)

def job_request(request):
    job_id = request.POST["j_id"]
    u_id = request.POST["lid"]
    resume = request.FILES['file']
    fss = FileSystemStorage()
    resume_file = fss.save(resume.name, resume)
    request_obj = jobrequest_table()
    request_obj.job = job_table.objects.get(id=job_id)
    request_obj.user = user_table.objects.get(login_id=u_id)
    request_obj.status = "pending"
    request_obj.resume = resume_file
    request_obj.date = datetime.today()
    request_obj.time = datetime.now().strftime("%H:%M:%S")
    request_obj.save()
    data = {'task': 'success'}
    r = json.dumps(data)
    return HttpResponse(r)


def view_suggested_clg(request):
    lid = request.POST['lid']
    clg_id = []
    ob = CollegeRequest.objects.filter(USER__login_id=lid)
    for i in ob:
        clg_id.append(i.ADMISSION.college.id)

    print("****************", clg_id)
    clg_obj = addmission_details_table.objects.exclude(college_id__in=clg_id)
    data = []
    for i in clg_obj:
        row = {'collegename': i.college.collegename, 'place': i.college.place, 'phoneno': i.college.phoneno,
               'course': i.courses.course, 'department': i.courses.department ,'duration': i.courses.duration,
               'admission_id': i.id}
        data.append(row)
    r = json.dumps(data)
    print("&&&&&&&&&&&&&&", r)
    return HttpResponse(r)



def send_application(request):
    admission_id = request.POST["admission_id"]
    u_id = request.POST["lid"]
    request_obj = CollegeRequest()
    request_obj.ADMISSION = addmission_details_table.objects.get(id=admission_id)
    request_obj.USER = user_table.objects.get(login_id=u_id)
    request_obj.status = "pending"
    request_obj.date = datetime.today()
    request_obj.save()
    data = {'task': 'success'}
    r = json.dumps(data)
    return HttpResponse(r)


def college_suggesion(request):
    lid = request.POST['lid']
    data = []
    st_details = user_table.objects.get(login__id=lid)
    mark = st_details.mark
    rank = st_details.rank

    ob = addmission_details_table.objects.filter(marks__lte=mark, rank=rank)
    for i in ob:
        row = {'collegename': i.college.collegename, 'place': i.college.place, 'phoneno': i.college.phoneno,
               'course': i.courses.course, 'department': i.courses.department ,'duration': i.courses.duration,
               'admission_id': i.id}
        data.append(row)
    r = json.dumps(data)
    print("&&&&&&&&&&&&&&", r)
    return HttpResponse(r)




